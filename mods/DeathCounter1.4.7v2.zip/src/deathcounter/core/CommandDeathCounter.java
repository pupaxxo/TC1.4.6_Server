package deathcounter.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cpw.mods.fml.common.FMLCommonHandler;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayer;

public class CommandDeathCounter extends CommandBase 
{

	@Override
	public String getCommandName() 
	{
		return "dc";
	}

	@Override
    public String getCommandUsage(ICommandSender par1ICommandSender)
    {
        return "/" + this.getCommandName() + " (leaderboard/reset) [all/user]";
    }
	
	@Override
    public List getCommandAliases()
    {
		return Arrays.asList(new String[] {"deathcounter"});
    }

	@Override
	public void processCommand(ICommandSender var1, String[] var2) 
	{
		if(var2.length > 0)
		{
			if("leaderboard".toLowerCase().startsWith(var2[0]))
			{
				if(var2.length >= 2)
				{
					if(var2[1].equalsIgnoreCase("all"))
					{
						broadcastLeaderboard(null);
						return;
					}
					else
					{
						broadcastLeaderboard(var2[1]);
						return;
					}
				}
				else
				{
					broadcastLeaderboard(var1.getCommandSenderName());
					return;
				}
			}
			else if("reset".toLowerCase().startsWith(var2[0]))
			{
				if(var2.length >= 2)
				{
					if(var2[1].equalsIgnoreCase("all"))
					{
						notifyAdmins(var1, "DC: Resetting deaths for all players");
						DeathCounter.console(var1.getCommandSenderName() + ": Resetting deaths for all players");
						return;
					}
					else
					{
						if(DeathCounter.instance.clearDeath(var2[1]))
						{
							notifyAdmins(var1, "DC: Resetting deaths for " + var2[1]);
							DeathCounter.console(var1.getCommandSenderName() + ": Resetting deaths for " + var2[1]);
							return;
						}
						else
						{
							var1.sendChatToPlayer("DC: " + var2[1] + " has no deaths.");
							return;
						}
					}
				}
				else
				{
					throw new WrongUsageException("/" + this.getCommandName() + " reset [all/user]", new Object[0]);
				}
			}
			else
			{
				throw new WrongUsageException("/" + this.getCommandName() + " (leaderboard/reset) [all/user]", new Object[0]);
			}
		}
		else
		{
			throw new WrongUsageException("/" + this.getCommandName() + " (leaderboard/reset) [all/user]", new Object[0]);
		}
	}

	public static void broadcastLeaderboard(String s)
	{
		ArrayList<EntityPlayer> playersToNotify = new ArrayList<EntityPlayer>();
		if(s != null)
		{
			if(!s.equals("Server"))
			{
				if(FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().getPlayerForUsername(s) == null)
				{
					return;
				}
				playersToNotify.add(FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().getPlayerForUsername(s));
			}
		}
		else
		{
			List players = FMLCommonHandler.instance().getMinecraftServerInstance().getConfigurationManager().playerEntityList;
			for(Object o : players)
			{
				EntityPlayer player = (EntityPlayer)o;
				playersToNotify.add(player);
			}
		}
		if(s != null && s.equals("Server"))
		{
			if(DeathCounter.ranking.isEmpty())
			{
				DeathCounter.console("No deaths have occured on this server yet.");
			}
			else
			{
				DeathCounter.console("Death Leaderboard:");
				for(int i = 1; i <= DeathCounter.leaderboardCount && i - 1 < DeathCounter.ranking.size(); i++)
				{
					DeathCounter.console("   " + DeathCounter.instance.getDisplayedRank(DeathCounter.ranking.get(i - 1)) + "  " + DeathCounter.ranking.get(i - 1) + " (" + DeathCounter.instance.getDeathCount(DeathCounter.ranking.get(i - 1)) + (DeathCounter.instance.getDeathCount(DeathCounter.ranking.get(i - 1)) == 1 ? " Death)" : " Deaths)"));
				}
			}
		}
		else
		{
			for(EntityPlayer player: playersToNotify)
			{
				if(DeathCounter.ranking.isEmpty())
				{
					player.addChatMessage("No deaths have occured on this server yet.");
				}
				else
				{
					boolean isPlayer = false;
					player.addChatMessage("Death Leaderboard:");
					for(int i = 1; i <= DeathCounter.leaderboardCount && i - 1 < DeathCounter.ranking.size(); i++)
					{
						String playerName = DeathCounter.ranking.get(i - 1);
						if(playerName.equals(player.username))
						{
							isPlayer = true;
						}
						int rank = DeathCounter.instance.getDisplayedRank(playerName);
						player.addChatMessage((rank == 1 ? "\u00A7e" : rank == 2 ? "\u00A77" : rank == 3 ? "\u00A74" : "") + (playerName.equals(player.username) ? " ->" : "    ") + rank + "  " + DeathCounter.ranking.get(i - 1) + " (" + DeathCounter.instance.getDeathCount(DeathCounter.ranking.get(i - 1)) + (DeathCounter.instance.getDeathCount(DeathCounter.ranking.get(i - 1)) == 1 ? " Death)" : " Deaths)"));
					}
					if(!isPlayer)
					{
						int rank = DeathCounter.instance.getDisplayedRank(player.username);
						player.addChatMessage(" ->" + rank + (rank >= 10 ? " " : "  ") + player.username + " (" + DeathCounter.instance.getDeathCount(player.username) + (DeathCounter.instance.getDeathCount(player.username) == 1 ? " Death)" : " Deaths)"));						
					}
				}
			}
		}
	}
	
}
