Fihgu's mods
Version: 2.1.2

This mod is for vanilla servers with minecraft forge.


How to Install:

//easy guide: ////////////////////////////////////////////////////
1.Install Minecraft Forge (6.5.0.467 *Version Does Matter*)
2.Install core into minecraft.jar/minecraft_server.jar
3.Put all other zips into "mods" folder
4.enjoy(this step is very important!)
//////////////////////////////////////////////////////////////////

//detials: ///////// read if things did not work out//////////////
if all other stuff is working, but you can't set region.
command tells you to click a block, but nothing happens when you click
then you didn't install the core mod right.

How to install "Core":
first open your ".jar" file with winrar.
then copy all the content inside the core zip, and paste them into
the ".jar" file.

How to install other parts:
copy them into ".minecraft/mods/".
if you don't have that folder, you need to install forge and run your game once.


Note:
This mod doesn't require a client side.
which means players who wants to connect to a server using this mod
will only need minecraft forge installed.
You only install this mod into clients when you want to use it in
LAN servers and single player.

Please use the forge version I give you ealier, it may(not always) cause problems
if you are using a different one.
//////////////////////////////////////////////////////////////////

==============================================================================================

For bug collecting:
fihgu's skype id: fanghan.hu

please add fihgu on skype and report any bug you found in the game.
suggestions are also welcomed.

==============================================================================================

If you want fihgu to develop a mod for you, or you need help on any java/c# related projects,
and you are willing to pay an acceptable price:

please also contact fihgu with skype.